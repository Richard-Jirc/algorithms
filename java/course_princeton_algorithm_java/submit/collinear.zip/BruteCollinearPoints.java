import java.util.Arrays;

public class BruteCollinearPoints {
    private final LineSegment[] result;
    private int count;

    public BruteCollinearPoints(Point[] points) {
        if (points == null) throw new IllegalArgumentException();
        result = new LineSegment[points.length];
        Point[] temp = new Point[4];
        count = 0;
        for (int p = 0; p < points.length - 3; p++) {
            temp[0] = points[p];
            for (int q = p + 1; q < points.length - 2; q++) {
                temp[1] = points[q];
                for (int r = q + 1; r < points.length -1; r++) {
                    temp[2] = points[r];
                    for (int s = r + 1; s < points.length; s++) {
                        temp[3] = points[s];
                        analyze(temp);
                    }
                }
            }
        }
    }

    private void analyze(Point[] list) {
        Arrays.sort(list);
        double longest = list[3].slopeTo(list[0]);
        boolean check = longest == list[3].slopeTo(list[1]) && longest == list[3].slopeTo(list[2]);
        if (check) {
            result[count] = new LineSegment(list[0], list[3]);
            count++;
        }
    }

    public int numberOfSegments() {
        return count;
    }
    public LineSegment[] segments() {
        LineSegment[] finalResult = new LineSegment[count];
        for (int i = 0; i < count; i++) {
            finalResult[i] = result[i];
        }
        return finalResult;
    }

    public static void main(String[] args) {

    }

}
